/**
 * sui_signer.js - Ký và tuần tự hóa chữ ký Sui zkLogin theo chuẩn @mysten/sui
 */
const { Ed25519Keypair } = require('@mysten/sui/keypairs/ed25519');
const { getZkLoginSignature } = require('@mysten/sui/zklogin');

async function main() {
  let input = '';
  process.stdin.setEncoding('utf-8');
  for await (const chunk of process.stdin) {
    input += chunk;
  }

  const data = JSON.parse(input);
  const { action = 'sign_personal_message', secretKeyHex, message, transactionBytes, zkProof, maxEpoch } = data;

  const rawSecret = Buffer.from(secretKeyHex, 'hex');
  const keypair = Ed25519Keypair.fromSecretKey(rawSecret);

  let userSig;
  if (action === 'sign_transaction') {
    const txBytes = Buffer.from(transactionBytes, 'base64');
    const res = await keypair.signTransaction(txBytes);
    userSig = res.signature;
  } else {
    // Ký PersonalMessage theo chuẩn Sui
    const msgBytes = new TextEncoder().encode(message);
    const res = await keypair.signPersonalMessage(msgBytes);
    userSig = res.signature;
  }

  // Tạo serialized zkLogin signature
  const zkLoginSig = getZkLoginSignature({
    inputs: zkProof,
    maxEpoch: maxEpoch,
    userSignature: userSig,
  });

  process.stdout.write(JSON.stringify({ signature: zkLoginSig }));
}

main().catch(err => {
  console.error(err);
  process.exit(1);
});
