# LOQUA AUTO ONBOARDING & ZKLOGIN BOT

Tool tự động hóa trọn gói cho dự án **Loqua (Sui Network - https://loqua.net)**: Thuê mail Edu -> Đăng nhập Google zkLogin -> Điểm danh 300 MP -> Bind mã Ref -> Gửi tin nhắn On-Chain Chat.

---

## ⚡ Quy trình hoạt động của Bot

```mermaid
flowchart LR
    A["1. Mua Mail Edu\n(ID: 5 -> 20579)"] --> B["2. Google zkLogin\n(Chrome CDP)"]
    B --> C["3. Bind Ref &\nĐiểm danh (+300 MP)"]
    C --> D["4. Chat On-Chain\n(Từ question.txt)"]
    D --> E["5. Xuất File\n(Session & Account)"]
```

---

## 🛠 1. Cài đặt môi trường

Chạy các lệnh sau tại thư mục dự án:

```bash
# Cài thư viện Python
pip install requests websockets cryptography python-dotenv

# Cài Sui SDK (Node.js)
npm install
```

---

## ⚙️ 2. Cấu hình file `.env`

Sao chép `.env.example` thành `.env` và điền cấu hình của bạn:

```ini
# Mã mời tài khoản chính (Ref Code)
INVITE_CODE=QEPLTMGTALHBA

# API shop thuê mail Edu (CMSNT / Shopclone)
CMSNT_SHOP_DOMAIN=https://www.shop1989nd.com
CMSNT_USERNAME=TenDangNhapShop
CMSNT_PASSWORD=MatKhauShop
CMSNT_PRODUCT_ID=5,20579

# Số lượng tài khoản và số luồng mặc định
COUNT=3
THREADS=1

# Tự động gửi tin nhắn chat từ question.txt
AUTO_CHAT=true
QUESTION_FILE=question.txt
```

> [!NOTE]
> `CMSNT_PRODUCT_ID=5,20579`: Bot sẽ **ưu tiên mua gói ID 5** (rẻ hơn 5%), nếu hết hàng trong kho sẽ tự động chuyển sang mua gói **ID 20579**.

---

## 🚀 3. Hướng dẫn sử dụng

### A. Tự động mua mail từ shop & tạo dàn ref mới
```bash
# Mua mail tự động và tạo 5 tài khoản ref
python loqua.py --buy --count 5

# Chạy đa luồng (ví dụ 2 luồng song song)
python loqua.py --buy --count 10 --threads 2
```

### B. Chạy On-Chain Chat hàng ngày cho dàn Ref (1-2 lần/ngày)
```bash
python loqua.py --chat-ref
```
* Tự động duyệt qua toàn bộ tài khoản trong `loqua_sessions.json`.
* Bốc ngẫu nhiên 1 câu chào hỏi xã giao từ kho 500 câu trong `question.txt` để gửi vào Global Chat On-chain.
* Tự động giãn cách thời gian giữa các tài khoản như người dùng thật.

### C. Đăng ký bằng Email có sẵn
```bash
python loqua.py --email "user@severnday.us" --password "MatKhau123"
```

---

## 📂 4. File dữ liệu xuất ra

* **`loqua_account.txt`**: Danh sách tài khoản đã xử lý (email, token, ví Sui, điểm MP, trạng thái chat).
* **`loqua_sessions.json`**: Phiên đăng nhập zkLogin lưu offline, dùng để chạy chat định kỳ hoặc làm mới token.
* **`question.txt`**: 500 câu chào hỏi xã giao vô thưởng vô phạt để bot bốc ngẫu nhiên gửi chat.
