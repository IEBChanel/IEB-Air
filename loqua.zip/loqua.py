"""
loqua.py — Tool tự động hóa đăng ký, liên kết ví Sui zkLogin & làm nhiệm vụ kèo Loqua (https://loqua.net)
Tích hợp:
  1. API thuê mail Edu từ CMSNT (Shopclone V5/V6) theo Postman doc (endpoint /api/BResource.php, ID 20579)
  2. Sui zkLogin qua Mysten Labs Enoki & Google OAuth
  3. Tự động Bind mã Ref (invite_code: QEPLTMGTALHBA) & Điểm danh hàng ngày (/sign-ins)
  4. Xuất kết quả tài khoản ra account.txt định dạng: email|auth_token|sui_address|refresh_token|expires_at
  5. Quản lý phiên zkLogin lưu offline (sessions.json) giúp tái sử dụng và refresh token suốt 48-72h kể cả khi mail thuê 24h đã hết hạn!
"""
import argparse
import asyncio
import base64
import json
import os
import random
import re
import secrets
import shutil
import subprocess
import sys
import tempfile
import time
import urllib.parse
from datetime import datetime

from cryptography.hazmat.primitives.asymmetric import ed25519
from dotenv import load_dotenv
import requests
import websockets

# Tải cấu hình từ file .env
load_dotenv()

# ==================== CẤU HÌNH HỆ THỐNG (CONFIG) ====================
# 1. Cấu hình site thuê mail Edu (CMSNT Shopclone V5/V6 - ví dụ: shop1989nd.com)
CMSNT_SHOP_DOMAIN = os.getenv("CMSNT_SHOP_DOMAIN", "https://www.shop1989nd.com").rstrip("/")
CMSNT_USERNAME = os.getenv("CMSNT_USERNAME", "SinArra")
CMSNT_PASSWORD = os.getenv("CMSNT_PASSWORD", "Giodong89")
CMSNT_PRODUCT_ID = os.getenv("CMSNT_PRODUCT_ID", "5,20579")

# 2. Cấu hình Loqua & Nhiệm vụ
BASE_URL = "https://loqua.net"
API_BASE = "https://api.loqua.net"
DEFAULT_INVITE_CODE = os.getenv("INVITE_CODE", "QEPLTMGTALHBA")
DEFAULT_COUNT = int(os.getenv("COUNT", "1"))
DEFAULT_THREADS = int(os.getenv("THREADS", "1"))

# 3. Cấu hình On-Chain Chat
AUTO_CHAT = os.getenv("AUTO_CHAT", "true").lower() in ("true", "1", "yes")
QUESTION_FILE = os.getenv("QUESTION_FILE", "question.txt")
raw_msgs = os.getenv(
    "CHAT_MESSAGES",
    "gm loqua,hi everyone,bullish on sui,gm fam,great project,hello loqua",
)
CHAT_MESSAGES = [m.strip() for m in raw_msgs.split(",") if m.strip()]


def load_chat_messages(file_path: str = QUESTION_FILE) -> list[str]:
    """Đọc toàn bộ các câu chat từ file question.txt, nếu rỗng thì fallback về danh sách mặc định"""
    if os.path.exists(file_path):
        try:
            with open(file_path, "r", encoding="utf-8") as f:
                lines = [line.strip() for line in f if line.strip() and not line.strip().startswith("#")]
            if lines:
                return lines
        except Exception as e:
            log(f"Không thể đọc file {file_path}: {e}", Colors.YELLOW)

    return CHAT_MESSAGES


def get_random_chat_message(file_path: str = QUESTION_FILE) -> str:
    """Lấy ngẫu nhiên 1 câu chat từ file question.txt"""
    msgs = load_chat_messages(file_path)
    return random.choice(msgs) if msgs else "gm everyone"

# 4. Cấu hình Sui zkLogin & Enoki
ENOKI_API_BASE = "https://api.enoki.mystenlabs.com"
ENOKI_PUBLIC_KEY = "enoki_public_3d496ea42df36e16d762cf5fa40cab95"
GOOGLE_CLIENT_ID = "503617615747-bkdlpckj4pdirac3ujtd1qkfm57g40kt.apps.googleusercontent.com"
GOOGLE_REDIRECT_URI = "https://loqua.net/google-auth-callback.html"
AUTH_AUDIENCE = "web"
LOGIN_MESSAGE_PREFIX = "Loqua Web Login"

ACCOUNTS_FILE = "account.txt"
SESSIONS_FILE = "sessions.json"

UA = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36"
)


class Colors:
    RESET = "\033[0m"
    RED = "\033[91m"
    GREEN = "\033[92m"
    YELLOW = "\033[93m"
    BLUE = "\033[94m"
    MAGENTA = "\033[95m"
    CYAN = "\033[96m"
    DIM = "\033[2m"
    BOLD = "\033[1m"


def init_console():
    if os.name == "nt":
        os.system("")
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass


def log(msg: str, color: str = Colors.RESET):
    now = datetime.now().strftime("%H:%M:%S")
    print(f"{Colors.DIM}[{now}]{Colors.RESET} {color}{msg}{Colors.RESET}", flush=True)


# ==================== PHẦN 1: CLIENT THUÊ MAIL EDU (CMSNT SHOPCLONE) ====================
class EduMailClient:
    """
    Client tương tác với API CMSNT Shopclone V5/V6 để kiểm tra số dư và thuê tài khoản mail Edu:
    - GetBalance.php: Xem số dư
    - BResource.php: Mua tài nguyên (Product ID ưu tiên: 5, dự phòng: 20579)
    """

    def __init__(self, domain=CMSNT_SHOP_DOMAIN, username=CMSNT_USERNAME, password=CMSNT_PASSWORD):
        self.domain = domain.rstrip("/")
        self.username = username
        self.password = password
        self.session = requests.Session()
        self.session.headers.update({"User-Agent": UA})

    def check_balance(self) -> dict:
        url = f"{self.domain}/api/GetBalance.php"
        params = {"username": self.username, "password": self.password}
        try:
            r = self.session.get(url, params=params, timeout=15)
            try:
                return r.json()
            except Exception:
                return {"status": "success", "balance": r.text.strip()}
        except Exception as e:
            return {"status": "error", "message": str(e)}

    def buy_single_product(self, product_id: str, amount: int = 1) -> tuple[bool, str, dict]:
        """Gửi yêu cầu mua tài nguyên với 1 product ID cụ thể"""
        url = f"{self.domain}/api/BResource.php"
        params = {
            "username": self.username,
            "password": self.password,
            "id": product_id,
            "amount": amount,
        }
        try:
            r = self.session.get(url, params=params, timeout=25)
            data = r.json()
            if data.get("status") in ("success", True) or data.get("success") is True:
                # Trích xuất dữ liệu account từ mảng lists hoặc data
                d = data.get("data") or {}
                lists = d.get("lists") or data.get("lists") or []
                raw_acc = ""
                if lists:
                    first = lists[0]
                    raw_acc = first.get("account") if isinstance(first, dict) else str(first)
                elif "account" in d:
                    raw_acc = d["account"]
                if raw_acc.strip():
                    return True, raw_acc.strip(), data
                return False, "Không nhận được dữ liệu tài khoản từ shop", data
            else:
                msg = data.get("msg") or data.get("message") or str(data)
                return False, msg, data
        except Exception as e:
            return False, str(e), {}

    def buy_edu_account(self, product_ids=None, amount: int = 1) -> tuple[bool, str, dict]:
        """
        Ưu tiên mua mail edu ID: 5 (rẻ hơn 5%), nếu 5 hết thì mới nhảy sang mua 20579.
        Trả về: (thành_công, email_pass_raw, full_response)
        """
        if product_ids is None:
            raw_ids = os.getenv("CMSNT_PRODUCT_ID", "5,20579")
            p_ids = [pid.strip() for pid in str(raw_ids).split(",") if pid.strip()]
            if not p_ids:
                p_ids = ["5", "20579"]
        elif isinstance(product_ids, (list, tuple)):
            p_ids = [str(x).strip() for x in product_ids]
        else:
            p_ids = [pid.strip() for pid in str(product_ids).split(",") if pid.strip()]

        last_err = ""
        last_data = {}
        for idx, pid in enumerate(p_ids):
            desc = "ưu tiên (rẻ hơn 5%)" if pid == "5" else "dự phòng"
            log(f"Đang kết nối API CMSNT thuê tài khoản mail Edu (ID: {pid} - {desc})...", Colors.CYAN)
            ok, raw_acc, data = self.buy_single_product(pid, amount=amount)
            if ok:
                log(f"Mua mail Edu thành công từ shop (ID: {pid}): {raw_acc}", Colors.GREEN)
                return True, raw_acc, data

            last_err = raw_acc
            last_data = data
            if idx < len(p_ids) - 1:
                log(
                    f"Mail Edu ID {pid} không khả dụng/hết hàng ({raw_acc}). Tự động nhảy sang ID {p_ids[idx+1]}...",
                    Colors.YELLOW,
                )

        return False, last_err, last_data


# ==================== PHẦN 2: CLIENT LOQUA & SUI ZKLOGIN ====================
class LoquaClient:
    """
    Client xử lý trọn gói quy trình Sui zkLogin, xác thực Loqua & làm nhiệm vụ:
    1. Tạo khóa Ephemeral Ed25519 & lấy nonce Enoki
    2. Tạo Google Auth URL
    3. Trao đổi Google ID Token lấy Sui Address & zkProof
    4. Ký xác thực Loqua Web Login (/auth/wallet/login)
    5. Bind mã Ref (/invites/referrals/bind)
    6. Điểm danh hàng ngày (/sign-ins)
    7. Refresh token tự động trong 48-72h kể cả khi mail thuê 24h đã hết hạn!
    """

    def __init__(self, proxy: dict = None):
        self.session = requests.Session()
        self.session.headers.update({"User-Agent": UA, "Accept": "application/json"})
        if proxy:
            self.session.proxies.update(proxy)

        self.ephemeral_priv = None
        self.ephemeral_priv_b64 = ""
        self.ephemeral_pub_bytes = None
        self.sui_pub_b64 = None
        self.enoki_nonce_data = {}
        self.state = None

        self.id_token = None
        self.sui_address = None
        self.salt = None
        self.zk_proof = None
        self.auth = {}

    @classmethod
    def from_session(cls, sess_data: dict):
        """Khôi phục đối tượng LoquaClient từ dữ liệu session đã lưu trong sessions.json"""
        client = cls()
        client.sui_address = sess_data.get("sui_address")
        client.sui_pub_b64 = sess_data.get("sui_public_key_b64")
        client.zk_proof = sess_data.get("zk_proof")
        auth_data = sess_data.get("auth") or sess_data.get("loqua_auth") or {}
        client.auth = auth_data
        client.loqua_auth = auth_data
        client.ephemeral_priv_b64 = sess_data.get("ephemeral_private_key_b64", "")
        client.enoki_nonce_data = {
            "maxEpoch": sess_data.get("max_epoch", 0),
            "estimatedExpiration": sess_data.get("estimated_expiration", int(time.time() * 1000) + 180000000),
        }
        priv_b64 = sess_data.get("ephemeral_private_key_b64")
        if priv_b64:
            try:
                raw_priv = base64.b64decode(priv_b64)
                client.ephemeral_priv = ed25519.Ed25519PrivateKey.from_private_bytes(raw_priv)
            except Exception:
                pass
        return client

    def prepare_zklogin(self) -> str:
        """
        Bước 1: Sinh khóa tạm thời Ed25519 và lấy Nonce từ Enoki:
        Trả về URL đăng nhập Google OAuth để mở popup / trình duyệt
        """
        # Sinh cặp khóa Ed25519
        self.ephemeral_priv = ed25519.Ed25519PrivateKey.generate()
        pub = self.ephemeral_priv.public_key()
        raw_pub = pub.public_bytes_raw()
        self.ephemeral_pub_bytes = raw_pub
        # Cấu trúc Sui Public Key: 0x00 (Flag Ed25519) + 32 bytes public key
        sui_pub_bytes = b"\x00" + raw_pub
        self.sui_pub_b64 = base64.b64encode(sui_pub_bytes).decode("utf-8")

        # Gọi Enoki lấy nonce
        url = f"{ENOKI_API_BASE}/v1/zklogin/nonce"
        headers = {
            "Authorization": f"Bearer {ENOKI_PUBLIC_KEY}",
            "Content-Type": "application/json",
        }
        payload = {"network": "mainnet", "ephemeralPublicKey": self.sui_pub_b64}
        r = self.session.post(url, headers=headers, json=payload, timeout=15)
        if r.status_code != 200:
            raise RuntimeError(f"Lỗi lấy Enoki nonce ({r.status_code}): {r.text}")

        res = r.json()
        self.enoki_nonce_data = res.get("data") or res
        enoki_nonce = self.enoki_nonce_data["nonce"]

        # Sinh state ngẫu nhiên
        self.state = secrets.token_hex(16)

        # Xây dựng URL Google OAuth
        params = {
            "client_id": GOOGLE_CLIENT_ID,
            "redirect_uri": GOOGLE_REDIRECT_URI,
            "response_type": "id_token",
            "scope": "openid email profile",
            "prompt": "select_account",
            "nonce": enoki_nonce,
            "state": self.state,
        }
        google_auth_url = (
            f"https://accounts.google.com/o/oauth2/v2/auth?{urllib.parse.urlencode(params)}"
        )
        return google_auth_url

    def complete_zklogin(self, id_token: str) -> dict:
        """
        Bước 2: Sử dụng Google ID Token để lấy zkProof, tính Sui Address,
        ký tin nhắn và đăng nhập lấy Loqua Auth Token.
        """
        self.id_token = id_token
        headers_enoki = {
            "Authorization": f"Bearer {ENOKI_PUBLIC_KEY}",
            "Content-Type": "application/json",
            "zklogin-jwt": id_token,
        }

        # 2a. Lấy Sui Address & Salt từ Enoki
        r_addr = self.session.get(f"{ENOKI_API_BASE}/v1/zklogin", headers=headers_enoki, timeout=15)
        if r_addr.status_code != 200:
            raise RuntimeError(f"Lỗi lấy zkLogin address ({r_addr.status_code}): {r_addr.text}")
        data_addr = r_addr.json().get("data") or {}
        self.sui_address = data_addr.get("address")
        self.salt = data_addr.get("salt")
        log(f"Địa chỉ ví Sui zkLogin: {Colors.CYAN}{self.sui_address}{Colors.RESET}", Colors.GREEN)

        # 2b. Lấy zkProof từ Enoki
        payload_zkp = {
            "network": "mainnet",
            "ephemeralPublicKey": self.sui_pub_b64,
            "maxEpoch": self.enoki_nonce_data["maxEpoch"],
            "randomness": self.enoki_nonce_data["randomness"],
        }
        r_zkp = self.session.post(
            f"{ENOKI_API_BASE}/v1/zklogin/zkp", headers=headers_enoki, json=payload_zkp, timeout=30
        )
        if r_zkp.status_code != 200:
            raise RuntimeError(f"Lỗi lấy Enoki zkProof ({r_zkp.status_code}): {r_zkp.text}")
        self.zk_proof = (r_zkp.json().get("data") or r_zkp.json())

        # 2c. Lấy Nonce xác thực từ Loqua Backend
        r_nonce = self.session.post(
            f"{API_BASE}/auth/wallet/nonce",
            json={
                "address": self.sui_address,
                "audience": AUTH_AUDIENCE,
                "login_message_prefix": LOGIN_MESSAGE_PREFIX,
            },
            timeout=15,
        )
        if r_nonce.status_code != 200:
            raise RuntimeError(f"Lỗi lấy Loqua nonce ({r_nonce.status_code}): {r_nonce.text}")
        nonce_info = r_nonce.json()
        nonce = nonce_info["nonce"]
        login_message = nonce_info["message"]

        # 2d. Ký và tuần tự hóa chữ ký Sui zkLogin qua sui_signer.js
        zklogin_sig = self._serialize_zklogin_signature(
            inputs=self.zk_proof,
            max_epoch=self.enoki_nonce_data["maxEpoch"],
            message=login_message,
        )

        # 2e. Đăng nhập vào Loqua (/auth/wallet/login)
        r_login = self.session.post(
            f"{API_BASE}/auth/wallet/login",
            json={
                "address": self.sui_address,
                "nonce": nonce,
                "message": login_message,
                "signature": zklogin_sig,
            },
            timeout=15,
        )
        if r_login.status_code != 200:
            raise RuntimeError(f"Đăng nhập Loqua thất bại ({r_login.status_code}): {r_login.text}")

        self.auth = r_login.json()
        log(
            f"Đăng nhập Loqua thành công! Token: {self.auth.get('access_token')[:25]}... "
            f"(Hạn token: {self.auth.get('expires_at')})",
            Colors.GREEN,
        )
        return self.auth

    def _serialize_zklogin_signature(self, inputs: dict, max_epoch: int, message: str) -> str:
        """
        Ký message và tuần tự hóa chữ ký Sui zkLogin chính thức chuẩn @mysten/sui (0x05 + BCS)
        """
        raw_secret_hex = self.ephemeral_priv.private_bytes_raw().hex()
        payload = {
            "secretKeyHex": raw_secret_hex,
            "message": message,
            "zkProof": inputs,
            "maxEpoch": max_epoch,
        }
        res = subprocess.run(
            ["node", "sui_signer.js"],
            input=json.dumps(payload),
            text=True,
            capture_output=True,
            check=True,
        )
        out = json.loads(res.stdout)
        return out["signature"]

    def get_token(self) -> str:
        """Lấy token xác thực từ auth hoặc loqua_auth"""
        return (self.auth or getattr(self, "loqua_auth", {})).get("access_token", "")

    def join_global_chat(self) -> bool:
        """Tham gia Global Chat để mở khóa quyền liên kết mã Ref (/global-chat/join)"""
        token = self.get_token()
        headers = {"Authorization": f"Bearer {token}"}
        req_id = secrets.token_hex(12)
        try:
            # 1. Chuẩn bị giao dịch tham gia Global Chat
            r_prep = self.session.post(
                f"{API_BASE}/global-chat/join/prepare?idempotent=1",
                headers=headers,
                json={"request_id": req_id},
                timeout=15,
            )
            if r_prep.status_code not in (200, 201):
                log(f"Lỗi prepare join chat ({r_prep.status_code}): {r_prep.text[:100]}", Colors.YELLOW)
                return False

            prep_data = r_prep.json()
            if prep_data.get("joined") is True:
                log("Ví đã ở trong Global Chat.", Colors.DIM)
                return True

            sponsorship_id = prep_data.get("sponsorship_id")
            tx_bytes = prep_data.get("transaction_bytes")
            if not sponsorship_id or not tx_bytes:
                log(f"Thiếu thông tin tài trợ join chat: {prep_data}", Colors.YELLOW)
                return False

            # 2. Ký transaction bytes bằng sui_signer.js
            raw_secret_hex = self.ephemeral_priv.private_bytes_raw().hex()
            payload = {
                "action": "sign_transaction",
                "secretKeyHex": raw_secret_hex,
                "transactionBytes": tx_bytes,
                "zkProof": self.zk_proof,
                "maxEpoch": self.enoki_nonce_data.get("maxEpoch"),
            }
            res = subprocess.run(
                ["node", "sui_signer.js"],
                input=json.dumps(payload),
                text=True,
                capture_output=True,
                check=True,
            )
            sig = json.loads(res.stdout)["signature"]

            # 3. Thực thi giao dịch onchain được tài trợ phí gas
            r_exec = self.session.post(
                f"{API_BASE}/global-chat/join/execute",
                headers=headers,
                json={
                    "sponsorship_id": sponsorship_id,
                    "transaction_bytes": tx_bytes,
                    "user_signature": sig,
                },
                timeout=20,
            )
            exec_data = r_exec.json() if r_exec.status_code in (200, 201) else {"error": r_exec.text}
            log(f"Join Global Chat: {r_exec.status_code} {str(exec_data)[:100]}", Colors.GREEN if r_exec.status_code in (200, 201) else Colors.YELLOW)
            time.sleep(2)
            return r_exec.status_code in (200, 201)
        except Exception as e:
            log(f"Lỗi join Global Chat: {e}", Colors.YELLOW)
            return False

    def bind_referral(self, invite_code: str = DEFAULT_INVITE_CODE) -> dict:
        """Bind mã mời tham gia dự án (/invites/referrals/bind)"""
        token = self.get_token()
        headers = {"Authorization": f"Bearer {token}"}
        try:
            r = self.session.post(
                f"{API_BASE}/invites/referrals/bind",
                headers=headers,
                json={"invite_code": invite_code},
                timeout=15,
            )
            # Nếu yêu cầu phải vào Global Chat trước
            if r.status_code == 409 and "GLOBAL_CHAT_MEMBER_REQUIRED" in r.text:
                log("Loqua yêu cầu join Global Chat trước khi Bind mã Ref. Đang tự động tham gia chat...", Colors.CYAN)
                joined = self.join_global_chat()
                if joined:
                    # Thử lại việc bind ref
                    r = self.session.post(
                        f"{API_BASE}/invites/referrals/bind",
                        headers=headers,
                        json={"invite_code": invite_code},
                        timeout=15,
                    )
            data = r.json() if r.status_code == 200 else {"error": r.text}
            if r.status_code == 500 and "DATABASE_ERROR" in r.text:
                log(f"Máy chủ Loqua đang nghẽn database Ref ({r.text[:80]}). Đã lưu mã mời vào session để tự động bind lại.", Colors.YELLOW)
            else:
                log(f"Bind Ref [{invite_code}]: {r.status_code} {str(data)[:120]}", Colors.GREEN if r.status_code == 200 else Colors.YELLOW)
            return data
        except Exception as e:
            log(f"Lỗi bind ref: {e}", Colors.RED)
            return {"error": str(e)}

    def daily_check_in(self) -> dict:
        """Thực hiện điểm danh nhận điểm hàng ngày (/sign-ins)"""
        token = self.get_token()
        headers = {"Authorization": f"Bearer {token}"}
        payload = {
            "source": "auth",
            "metadata": {
                "client": "web",
                "login_type": "zklogin",
                "signature_scheme": "ZkLogin",
            },
        }
        try:
            r = self.session.post(f"{API_BASE}/sign-ins", headers=headers, json=payload, timeout=15)
            data = r.json() if r.status_code == 200 else {"error": r.text}
            log(f"Điểm danh nhận điểm: {r.status_code} {str(data)[:120]}", Colors.GREEN if r.status_code == 200 else Colors.YELLOW)
            return data
        except Exception as e:
            log(f"Lỗi điểm danh: {e}", Colors.RED)
            return {"error": str(e)}

    def get_reward_points(self) -> dict:
        """Xem tổng điểm thưởng của ví (/reward-points)"""
        token = self.get_token()
        headers = {"Authorization": f"Bearer {token}"}
        try:
            r = self.session.get(
                f"{API_BASE}/reward-points",
                headers=headers,
                params={"wallet_address": self.sui_address},
                timeout=15,
            )
            return r.json() if r.status_code == 200 else {}
        except Exception:
            return {}

    def send_onchain_chat_via_browser(self, message: str = None) -> bool:
        """
        Gửi tin nhắn on-chain vào Global Chat (#web-messages) thông qua Chrome CDP & session zkLogin.
        Tự động lấy câu chat ngẫu nhiên từ file question.txt nếu không truyền message.
        """
        if not message:
            message = get_random_chat_message()

        log(f"Đang tự động gửi On-Chain Chat từ question.txt: \"{message}\"...", Colors.CYAN)
        priv_key_str = ""
        if self.ephemeral_priv:
            priv_key_str = base64.b64encode(self.ephemeral_priv.private_bytes_raw()).decode("utf-8")
        elif getattr(self, "ephemeral_priv_b64", None):
            priv_key_str = self.ephemeral_priv_b64

        frontend_session = {
            "provider": "google",
            "idToken": self.id_token or "",
            "address": self.sui_address,
            "salt": self.sui_address,
            "publicKey": self.sui_pub_b64,
            "clientId": GOOGLE_CLIENT_ID,
            "legacy": False,
            "ephemeralSecretKey": priv_key_str,
            "zkProof": self.zk_proof,
            "maxEpoch": self.enoki_nonce_data.get("maxEpoch", 0),
            "randomness": (self.zk_proof or {}).get("addressSeed", "0"),
            "loquaAuth": self.auth,
            "authMessage": "Loqua Web Login",
            "authSignature": "",
            "createdAt": int(time.time() * 1000),
            "expiresAt": self.enoki_nonce_data.get("estimatedExpiration", int(time.time() * 1000) + 180000000),
        }

        async def _do_chat():
            chrome_path = find_chrome_executable()
            temp_dir = tempfile.mkdtemp(prefix="chat_")
            port = secrets.randbelow(500) + 9400
            cmd = [
                chrome_path,
                f"--remote-debugging-port={port}",
                f"--user-data-dir={temp_dir}",
                "--no-first-run",
                "--no-default-browser-check",
                f"{BASE_URL}/#web-messages",
            ]
            proc = subprocess.Popen(cmd)
            try:
                ws_url = None
                for _ in range(25):
                    await asyncio.sleep(1)
                    try:
                        res = urllib.request.urlopen(f"http://127.0.0.1:{port}/json", timeout=2).read()
                        tabs = json.loads(res.decode())
                        pages = [t for t in tabs if t.get("type") == "page"]
                        if pages:
                            ws_url = pages[0]["webSocketDebuggerUrl"]
                            break
                    except Exception:
                        pass
                if not ws_url:
                    return False

                async with websockets.connect(ws_url) as ws:
                    msg_ctr = 1
                    async def eval_js(expr):
                        nonlocal msg_ctr
                        msg_ctr += 1
                        await ws.send(json.dumps({
                            "id": msg_ctr,
                            "method": "Runtime.evaluate",
                            "params": {"expression": expr, "returnByValue": True}
                        }))
                        while True:
                            resp = json.loads(await ws.recv())
                            if resp.get("id") == msg_ctr:
                                return resp.get("result", {}).get("result", {}).get("value")

                    await asyncio.sleep(2)
                    sess_json = json.dumps(frontend_session)
                    inv_code = getattr(self, "current_invite_code", DEFAULT_INVITE_CODE)
                    await eval_js(f'''
                        window.localStorage.setItem("loqua.zklogin.session.mainnet", JSON.stringify({sess_json}));
                        window.localStorage.setItem("loqua.pendingReferralInviteCode", "{inv_code}");
                        window.location.reload();
                    ''')

                    for _ in range(10):
                        await asyncio.sleep(2)
                        st = await eval_js('''
                            (function() {
                                var inp = document.querySelector('textarea.web-chat-input') || document.querySelector('.web-chat-input');
                                if (!inp) return "loading";
                                return "ready";
                            })()
                        ''')
                        if st == "ready":
                            break

                    msg_json = json.dumps(message)
                    sent = await eval_js(f'''
                        (function() {{
                            var inp = document.querySelector('textarea.web-chat-input') || document.querySelector('.web-chat-input');
                            if (!inp) return "no_input";
                            inp.focus();
                            inp.value = {msg_json};
                            inp.dispatchEvent(new Event('input', {{ bubbles: true }}));
                            inp.dispatchEvent(new Event('change', {{ bubbles: true }}));
                            var btn = document.querySelector('button.web-chat-send') || document.querySelector('.web-chat-panel button[type="submit"]');
                            if (btn) {{
                                btn.click();
                                return "clicked_btn";
                            }}
                            inp.dispatchEvent(new KeyboardEvent('keydown', {{ key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true }}));
                            return "sent_enter";
                        }})()
                    ''')
                    await asyncio.sleep(3)
                    return sent in ("clicked_btn", "sent_enter")
            finally:
                try:
                    proc.terminate()
                    proc.wait(timeout=3)
                except Exception:
                    pass
                try:
                    shutil.rmtree(temp_dir, ignore_errors=True)
                except Exception:
                    pass

        try:
            ok = asyncio.run(_do_chat())
            if ok:
                log(f"Đã gửi tin nhắn On-Chain Chat thành công: \"{message}\"", Colors.GREEN)
                return True
            else:
                log("Chưa thể gửi tin nhắn On-Chain Chat (khung chat chưa tải xong)", Colors.YELLOW)
                return False
        except Exception as e:
            log(f"Lỗi gửi On-Chain Chat: {e}", Colors.YELLOW)
            return False

    def save_session(self, email: str, points: int = 0, chat_status: str = "none", invite_code: str = DEFAULT_INVITE_CODE):
        """Lưu phiên zkLogin đầy đủ để refresh token trong 48-72h tiếp theo & xuất account.txt"""
        priv_bytes = self.ephemeral_priv.private_bytes_raw()
        session_record = {
            "email": email,
            "sui_address": self.sui_address,
            "ephemeral_private_key_b64": base64.b64encode(priv_bytes).decode("utf-8"),
            "sui_public_key_b64": self.sui_pub_b64,
            "max_epoch": self.enoki_nonce_data.get("maxEpoch"),
            "estimated_expiration": self.enoki_nonce_data.get("estimatedExpiration"),
            "zk_proof": self.zk_proof,
            "auth": self.auth,
            "points": points,
            "chat_status": chat_status,
            "invite_code": invite_code,
            "created_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        }

        # Lưu vào sessions.json
        sessions = {}
        if os.path.exists(SESSIONS_FILE):
            try:
                with open(SESSIONS_FILE, "r", encoding="utf-8") as f:
                    sessions = json.load(f)
            except Exception:
                sessions = {}
        sessions[email] = session_record
        with open(SESSIONS_FILE, "w", encoding="utf-8") as f:
            json.dump(sessions, f, indent=2, ensure_ascii=False)

        # Xuất ra account.txt: email|auth_token|sui_address|points|chat_status|invite_code|expires_at
        acc_token = self.auth.get("access_token", "")
        exp_at = self.auth.get("expires_at", "")
        with open(ACCOUNTS_FILE, "a", encoding="utf-8") as f:
            f.write(f"{email}|{acc_token}|{self.sui_address}|{points}|{chat_status}|{invite_code}|{exp_at}\n")
        log(f"Đã lưu tài khoản vào {ACCOUNTS_FILE} & {SESSIONS_FILE}", Colors.GREEN)


# ==================== PHẦN 3: TỰ ĐỘNG HÓA CHROME CDP (GOOGLE LOGIN POPUP) ====================
def find_chrome_executable() -> str:
    paths = [
        r"C:\Program Files\Google\Chrome\Application\chrome.exe",
        r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
        os.path.expandvars(r"%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe"),
    ]
    for p in paths:
        if os.path.isfile(p):
            return p
    return "chrome"


async def async_login_google_cdp(email: str, password: str, auth_url: str, headless: bool = False) -> str:
    """
    Sử dụng Chrome DevTools Protocol (CDP) trực tiếp qua WebSockets để tự động:
    1. Mở cửa sổ đăng nhập Google OAuth
    2. Điền email và ấn Tiếp tục
    3. Điền mật khẩu và ấn Tiếp tục
    4. Xử lý màn hình điều khoản Workspace Speedbump ("Tôi hiểu" / "I understand")
    5. Xử lý màn hình chấp thuận ủy quyền OAuth ("Tiếp tục" / "Continue")
    6. Bắt URL chuyển hướng google-auth-callback.html#id_token=... và trích xuất id_token
    """
    chrome_path = find_chrome_executable()
    temp_dir = tempfile.mkdtemp(prefix="chrome_")
    port = secrets.randbelow(500) + 9300  # Cổng ngẫu nhiên 9300-9800 tránh xung đột

    cmd = [
        chrome_path,
        f"--remote-debugging-port={port}",
        f"--user-data-dir={temp_dir}",
        "--no-first-run",
        "--no-default-browser-check",
        "--disable-sync",
        auth_url,
    ]

    log(f"Đang khởi động Chrome CDP (port {port})...", Colors.CYAN)
    proc = subprocess.Popen(cmd)

    id_token = None
    try:
        # Chờ endpoint CDP sẵn sàng
        ws_url = None
        for _ in range(25):
            await asyncio.sleep(1)
            try:
                res = urllib.request.urlopen(f"http://127.0.0.1:{port}/json", timeout=2).read()
                tabs = json.loads(res.decode())
                pages = [t for t in tabs if t.get("type") == "page"]
                if pages:
                    ws_url = pages[0]["webSocketDebuggerUrl"]
                    break
            except Exception:
                pass

        if not ws_url:
            raise RuntimeError("Không thể kết nối Chrome DevTools Protocol!")

        async with websockets.connect(ws_url) as ws:
            msg_counter = 1

            async def send_eval(expr: str):
                nonlocal msg_counter
                msg_counter += 1
                payload = {
                    "id": msg_counter,
                    "method": "Runtime.evaluate",
                    "params": {"expression": expr, "returnByValue": True},
                }
                await ws.send(json.dumps(payload))
                while True:
                    resp = json.loads(await ws.recv())
                    if resp.get("id") == msg_counter:
                        return resp.get("result", {}).get("result", {}).get("value")

            email_filled = False
            pass_filled = False

            for step in range(50):
                await asyncio.sleep(1.5)

                cur_url = await send_eval("window.location.href")
                if not cur_url:
                    continue

                # Kiểm tra nếu đã đến trang redirect mang theo id_token
                if "google-auth-callback.html" in cur_url and "id_token=" in cur_url:
                    parsed = urllib.parse.urlparse(cur_url)
                    params = urllib.parse.parse_qs(parsed.fragment or parsed.query)
                    if "id_token" in params:
                        id_token = params["id_token"][0]
                        log("Đã bắt được Google ID Token thành công!", Colors.GREEN)
                        break

                # 1. Điền Email
                if not email_filled:
                    res_email = await send_eval(f'''
                        (function() {{
                            var inp = document.querySelector('input[type="email"]') || document.querySelector('input[name="identifier"]');
                            if (!inp) return "no_input";
                            inp.focus();
                            inp.value = "{email}";
                            inp.dispatchEvent(new Event('input', {{ bubbles: true }}));
                            inp.dispatchEvent(new Event('change', {{ bubbles: true }}));
                            var btn = document.getElementById("identifierNext") || document.querySelector('button[type="button"]');
                            if (btn) btn.click();
                            return "done";
                        }})()
                    ''')
                    if res_email == "done":
                        log(f"Đã nhập Email: {email}", Colors.DIM)
                        email_filled = True
                        await asyncio.sleep(2)
                        continue

                # 2. Điền Mật khẩu
                if email_filled and not pass_filled:
                    res_pass = await send_eval(f'''
                        (function() {{
                            var inp = document.querySelector('input[type="password"]') || document.querySelector('input[name="Passwd"]');
                            if (!inp) return "no_input";
                            inp.focus();
                            inp.value = "{password}";
                            inp.dispatchEvent(new Event('input', {{ bubbles: true }}));
                            inp.dispatchEvent(new Event('change', {{ bubbles: true }}));
                            var btn = document.getElementById("passwordNext") || document.querySelector('#passwordNext button');
                            if (btn) btn.click();
                            return "done";
                        }})()
                    ''')
                    if res_pass == "done":
                        log("Đã nhập Mật khẩu và xác nhận", Colors.DIM)
                        pass_filled = True
                        await asyncio.sleep(2)
                        continue

                # 3. Xử lý Workspace Speedbump ("Tôi hiểu") / Consent ("Tiếp tục")
                if pass_filled:
                    res_accept = await send_eval('''
                        (function() {
                            var btns = Array.from(document.querySelectorAll('button, div[role="button"], a[role="button"]'));
                            for (var b of btns) {
                                var txt = (b.innerText || "").toLowerCase();
                                if (txt.includes("understand") || txt.includes("accept") || txt.includes("hiểu") || 
                                    txt.includes("tiếp tục") || txt.includes("agree") || txt.includes("continue") || 
                                    txt.includes("allow") || txt.includes("cho phép") || txt.includes("confirm")) {
                                    b.click();
                                    return "clicked: " + txt;
                                }
                            }
                            var acc = document.querySelector('#accept');
                            if (acc) { acc.click(); return "clicked_#accept"; }
                            return "none";
                        })()
                    ''')
                    if res_accept and res_accept != "none":
                        log(f"Tự động bấm xác nhận Google: {res_accept}", Colors.DIM)
                        await asyncio.sleep(2)
                        continue

    finally:
        try:
            proc.terminate()
            proc.wait(timeout=3)
        except Exception:
            pass
        try:
            shutil.rmtree(temp_dir, ignore_errors=True)
        except Exception:
            pass

    return id_token


def login_google_with_chrome(email: str, password: str, auth_url: str) -> str:
    try:
        return asyncio.run(async_login_google_cdp(email, password, auth_url))
    except Exception as e:
        log(f"Lỗi đăng nhập Google Chrome CDP: {e}", Colors.YELLOW)
        return None


# ==================== PHẦN 4: HÀM ĐIỀU PHỐI CHÍNH ====================
def run_single_account(
    email: str = None,
    password: str = None,
    buy_new: bool = False,
    manual_mode: bool = False,
    cached_acc: tuple = None,
    invite_code: str = DEFAULT_INVITE_CODE,
    do_chat: bool = AUTO_CHAT,
) -> bool:
    """
    Thực hiện quy trình trọn gói cho 1 tài khoản:
    1. Mua/nhận email Edu
    2. Google OAuth zkLogin & lấy ví Sui + Loqua Auth JWT
    3. Điểm danh nhận thưởng (/sign-ins)
    4. Tham gia On-Chain Global Chat & Liên kết mã Ref (/invites/referrals/bind)
    5. Gửi tin nhắn On-Chain Chat
    6. Lưu offline session & xuất account.txt
    """
    # 1. Thuê mail Edu nếu chọn mua tự động
    if cached_acc:
        email, password = cached_acc
    elif buy_new:
        edu_client = EduMailClient()
        bal = edu_client.check_balance()
        log(f"Số dư tài khoản CMSNT: {bal.get('balance') or bal.get('data') or bal}", Colors.DIM)

        ok, raw_acc, resp = edu_client.buy_edu_account()
        if not ok or not raw_acc:
            log(f"Lỗi mua mail Edu từ shop: {raw_acc}", Colors.RED)
            return False
        parts = raw_acc.split("|")
        email = parts[0].strip()
        password = parts[1].strip() if len(parts) > 1 else ""

    if not email:
        email = input("Nhập Email Edu Google: ").strip()
    if not password and not manual_mode:
        password = input("Nhập Mật khẩu Email: ").strip()

    log(f"Bắt đầu khởi tạo zkLogin cho tài khoản: {Colors.BOLD}{email}{Colors.RESET}", Colors.CYAN)

    # 2. Khởi tạo phiên zkLogin & lấy URL Google OAuth
    client = LoquaClient()
    client.current_invite_code = invite_code
    google_url = client.prepare_zklogin()

    id_token = None
    if not manual_mode and password:
        id_token = login_google_with_chrome(email, password, google_url)

    # Nếu chưa có ID token hoặc chạy manual mode: hướng dẫn dán URL
    if not id_token:
        print(f"\n{Colors.YELLOW}{Colors.BOLD}=== HƯỚNG DẪN ĐĂNG NHẬP GOOGLE OAUTH ==={Colors.RESET}")
        print(f"1. Mở liên kết dưới đây trên trình duyệt:\n{Colors.CYAN}{google_url}{Colors.RESET}")
        print("2. Đăng nhập vào tài khoản Google Edu của bạn.")
        print("3. Sau khi xác nhận, trình duyệt chuyển hướng đến trang 'google-auth-callback.html#id_token=...'")
        callback_url = input("\n👉 Dán toàn bộ URL chuyển hướng (hoặc chuỗi id_token): ").strip()

        if "id_token=" in callback_url:
            parsed = urllib.parse.urlparse(callback_url)
            params = urllib.parse.parse_qs(parsed.fragment or parsed.query)
            id_token = params.get("id_token", [None])[0]
        else:
            id_token = callback_url

    if not id_token:
        log("Không tìm thấy Google ID Token! Dừng tiến trình.", Colors.RED)
        return False

    # 3. Hoàn tất zkLogin & lấy Loqua Auth Token
    log("Đang xác thực zkProof với Enoki & ký ví Sui vào Loqua Backend...", Colors.CYAN)
    client.complete_zklogin(id_token)

    # 4. Gửi tin nhắn On-Chain Chat trước để kích hoạt thành viên & lịch sử chat Global Chat
    chat_status = "none"
    if do_chat:
        chat_ok = client.send_onchain_chat_via_browser()
        chat_status = "sent" if chat_ok else "failed"

    # 5. Tham gia Global Chat On-Chain & Bind Invite Code
    log(f"Đang liên kết mã mời: {invite_code}...", Colors.CYAN)
    client.bind_referral(invite_code)

    # 6. Điểm danh nhận thưởng
    log("Đang thực hiện điểm danh hàng ngày...", Colors.CYAN)
    client.daily_check_in()

    # 7. Kiểm tra điểm thưởng
    pts_data = client.get_reward_points()
    total_pts = pts_data.get("total_points", 300)
    log(f"Điểm thưởng hiện tại: {total_pts} MP", Colors.GREEN)

    # 8. Lưu tài khoản
    client.save_session(email, points=total_pts, chat_status=chat_status, invite_code=invite_code)
    log("🎉 ĐÃ HOÀN TẤT ĐĂNG KÝ VÀ LÀM NHIỆM VỤ THÀNH CÔNG!", Colors.GREEN)
    return True


def run_batch(
    count: int = DEFAULT_COUNT,
    threads: int = DEFAULT_THREADS,
    buy_new: bool = False,
    manual_mode: bool = False,
    email: str = None,
    password: str = None,
    invite_code: str = DEFAULT_INVITE_CODE,
    do_chat: bool = AUTO_CHAT,
):
    init_console()
    print(
        f"{Colors.GREEN}{Colors.BOLD}=== LOQUA AUTO ONBOARDING & ZKLOGIN BOT | Ref: {invite_code} | Total: {count} | Threads: {threads} ==={Colors.RESET}",
        flush=True,
    )

    success_count = 0

    if threads <= 1 or count <= 1 or manual_mode:
        # Chạy tuần tự
        for i in range(1, count + 1):
            log(f"\n========== [ACCOUNT {i}/{count}] ==========", Colors.MAGENTA)
            ok = run_single_account(
                email=email if i == 1 else None,
                password=password if i == 1 else None,
                buy_new=buy_new,
                manual_mode=manual_mode,
                invite_code=invite_code,
                do_chat=do_chat,
            )
            if ok:
                success_count += 1
            if i < count:
                log("Nghỉ 3 giây trước tài khoản tiếp theo...", Colors.DIM)
                time.sleep(3)
    else:
        # Chạy đa luồng
        from concurrent.futures import ThreadPoolExecutor, as_completed

        log(f"Đang kích hoạt {threads} luồng xử lý song song...", Colors.CYAN)
        with ThreadPoolExecutor(max_workers=threads) as executor:
            futures = [
                executor.submit(
                    run_single_account,
                    None,
                    None,
                    buy_new,
                    manual_mode,
                    None,
                    invite_code,
                    do_chat,
                )
                for _ in range(count)
            ]
            for f in as_completed(futures):
                try:
                    if f.result():
                        success_count += 1
                except Exception as e:
                    log(f"Lỗi luồng: {e}", Colors.RED)

    log(f"\n🏁 KẾT THÚC TIẾN TRÌNH: Thành công {success_count}/{count} tài khoản!", Colors.GREEN)


def run_daily_chat_for_sessions(sessions_file: str = SESSIONS_FILE, delay_min: int = 5, delay_max: int = 15):
    """
    Duyệt qua danh sách tài khoản dàn ref trong sessions.json
    và tự động gửi tin nhắn on-chain ngẫu nhiên từ file question.txt (chạy 1-2 lần/ngày)
    """
    if not os.path.exists(sessions_file):
        log(f"Không tìm thấy file lưu phiên: {sessions_file}!", Colors.RED)
        return

    try:
        with open(sessions_file, "r", encoding="utf-8") as f:
            sessions = json.load(f)
    except Exception as e:
        log(f"Lỗi đọc file {sessions_file}: {e}", Colors.RED)
        return

    if not sessions:
        log(f"Chưa có tài khoản nào trong {sessions_file}!", Colors.YELLOW)
        return

    items = list(sessions.items())
    log(f"\n🚀 BẮT ĐẦU CHẠY ON-CHAIN CHAT TỪ {QUESTION_FILE} CHO DÀN REF ({len(items)} tài khoản)...", Colors.GREEN)
    success = 0
    for idx, (email, sess) in enumerate(items, 1):
        log(f"\n[{idx}/{len(items)}] Đang xử lý chat cho tài khoản: {Colors.BOLD}{email}{Colors.RESET}", Colors.MAGENTA)
        try:
            client = LoquaClient.from_session(sess)
            msg = get_random_chat_message()
            ok = client.send_onchain_chat_via_browser(msg)
            if ok:
                success += 1
                sess["chat_status"] = "sent"
                sess["last_chat_at"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            else:
                sess["chat_status"] = "failed"

            # Cập nhật trạng thái vào file sessions
            with open(sessions_file, "w", encoding="utf-8") as f:
                json.dump(sessions, f, indent=2, ensure_ascii=False)
        except Exception as e:
            log(f"Lỗi khi gửi chat cho {email}: {e}", Colors.RED)

        if idx < len(items):
            delay = random.randint(delay_min, delay_max)
            log(f"Nghỉ ngẫu nhiên {delay}s trước tài khoản tiếp theo...", Colors.DIM)
            time.sleep(delay)

    log(f"\n🏁 HOÀN TẤT CHAT HÀNG NGÀY CHO DÀN REF: {success}/{len(items)} tài khoản thành công!", Colors.GREEN)


def bind_all_saved_sessions(invite_code: str = DEFAULT_INVITE_CODE, sessions_file: str = SESSIONS_FILE):
    """Liên kết lại mã Ref cho toàn bộ các tài khoản đã lưu trong sessions.json"""
    if not os.path.exists(sessions_file):
        log(f"Không tìm thấy file {sessions_file}!", Colors.RED)
        return

    try:
        with open(sessions_file, "r", encoding="utf-8") as f:
            sessions = json.load(f)
    except Exception as e:
        log(f"Lỗi đọc file {sessions_file}: {e}", Colors.RED)
        return

    if not sessions:
        log("Chưa có tài khoản nào trong sessions.json!", Colors.YELLOW)
        return

    log(f"\n🚀 Đang kiểm tra & Bind mã Ref [{invite_code}] cho {len(sessions)} tài khoản...", Colors.CYAN)
    success = 0
    for idx, (email, sess) in enumerate(sessions.items(), 1):
        log(f"\n[{idx}/{len(sessions)}] Tài khoản: {email}", Colors.MAGENTA)
        client = LoquaClient.from_session(sess)
        res = client.bind_referral(invite_code)
        if res.get("status") in ("ok", "success") or "referral" in res:
            success += 1
            sess["invite_code"] = invite_code
        time.sleep(1)

    try:
        with open(sessions_file, "w", encoding="utf-8") as f:
            json.dump(sessions, f, indent=2, ensure_ascii=False)
    except Exception:
        pass

    log(f"\n🏁 Kết quả Bind Ref: {success}/{len(sessions)} tài khoản thành công!", Colors.GREEN)


init_console()


def main():
    ap = argparse.ArgumentParser(description="Loqua Auto Onboarding & zkLogin Bot")
    ap.add_argument("--buy", action="store_true", help="Tự động gọi API mua mail Edu từ shop CMSNT")
    ap.add_argument("--count", type=int, default=DEFAULT_COUNT, help=f"Số lượng tài khoản (mặc định: {DEFAULT_COUNT})")
    ap.add_argument("--threads", type=int, default=DEFAULT_THREADS, help=f"Số luồng chạy song song (mặc định: {DEFAULT_THREADS})")
    ap.add_argument("--ref", default=DEFAULT_INVITE_CODE, help=f"Mã mời liên kết (mặc định: {DEFAULT_INVITE_CODE})")
    ap.add_argument("--no-chat", action="store_true", help="Bỏ qua bước gửi tin nhắn On-Chain Chat")
    ap.add_argument("--chat-ref", action="store_true", help="Chạy gửi tin nhắn chat từ question.txt cho toàn bộ dàn ref trong sessions.json (chạy 1-2 lần/ngày)")
    ap.add_argument("--bind-ref", action="store_true", help="Thử lại liên kết mã Ref cho toàn bộ các tài khoản đã lưu trong sessions.json")
    ap.add_argument("--email", default=None, help="Email Google Edu nếu có sẵn")
    ap.add_argument("--password", default=None, help="Mật khẩu email Google Edu")
    ap.add_argument("--manual", action="store_true", help="Chạy chế độ dán URL chuyển hướng thủ công")
    args = ap.parse_args()

    if args.bind_ref:
        bind_all_saved_sessions(args.ref)
        return

    if args.chat_ref:
        run_daily_chat_for_sessions()
        return

    run_batch(
        count=args.count,
        threads=args.threads,
        buy_new=args.buy,
        manual_mode=args.manual,
        email=args.email,
        password=args.password,
        invite_code=args.ref,
        do_chat=not args.no_chat and AUTO_CHAT,
    )


if __name__ == "__main__":
    main()
